﻿#Requires -Version 5.1
[CmdletBinding()]
param(
 [string]$InstallDir=(Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SparrowFyWorker'),
 [string]$ServerUrl='https://sparrowfy.ddns.info/',
 [string]$TaskName='sparrowfy-worker',
 [switch]$ConfigureOnly,
 [switch]$SkipPairing
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$utf8=New-Object Text.UTF8Encoding($false)
function Save-Text($Path,$Text){[IO.File]::WriteAllText($Path,$Text,$utf8)}
function Refresh-Path {
 $env:PATH=[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')+';'+$env:LOCALAPPDATA+'\Microsoft\WindowsApps;'+$env:LOCALAPPDATA+'\Microsoft\WinGet\Links'
}
function Find-Winget {
 Refresh-Path
 $c=Get-Command winget.exe -ErrorAction SilentlyContinue
 if($c){try{$v=& $c.Source --version 2>$null;if($LASTEXITCODE -eq 0 -and "$v" -match '\d+\.\d+'){return $c.Source}}catch{}}
 return $null
}
function Ensure-Winget {
 Write-Host '[1/6] Comprobando winget...'
 $exe=Find-Winget
 if(!$exe){
  Write-Host 'Registrando el Instalador de aplicaciones de Windows...'
  try{Add-AppxPackage -RegisterByFamilyName -MainPackage Microsoft.DesktopAppInstaller_8wekyb3d8bbwe -ErrorAction Stop}catch{Write-Warning $_.Exception.Message}
  $exe=Find-Winget
 }
 if(!$exe){throw 'Instala o actualiza el Instalador de aplicaciones de Microsoft desde https://aka.ms/getwinget y vuelve a ejecutar este archivo. En Windows 10 puede ser necesario actualizar Windows.'}
 & $exe show --id Python.Python.3.13 --exact --source winget --accept-source-agreements --disable-interactivity | Out-Host
 if($LASTEXITCODE -ne 0){
  Write-Warning 'winget no puede consultar paquetes; intentando actualizar App Installer...'
  & $exe upgrade --id Microsoft.AppInstaller --exact --accept-source-agreements --accept-package-agreements --disable-interactivity | Out-Host
  & $exe source update --name winget --disable-interactivity | Out-Host
  & $exe show --id Python.Python.3.13 --exact --source winget --accept-source-agreements --disable-interactivity | Out-Host
  if($LASTEXITCODE -ne 0){throw 'winget sigue fallando. Actualiza Instalador de aplicaciones desde https://aka.ms/getwinget y reintenta. No se ha registrado la tarea.'}
 }
 return $exe
}
function Install-Package($Id){
 & $script:wingetPath install --id $Id --exact --source winget --scope user --silent --accept-source-agreements --accept-package-agreements --disable-interactivity | Out-Host
 if($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne -1978335189){throw "No se pudo instalar $Id (codigo $LASTEXITCODE). Revisa la salida de winget."}
 Refresh-Path
}
function Find-Python {
 $paths=New-Object 'System.Collections.Generic.List[string]'
 $c=Get-Command python.exe -ErrorAction SilentlyContinue
 if($c -and $c.Source -notlike '*\WindowsApps\*'){$paths.Add($c.Source)}
 foreach($base in @("$env:LOCALAPPDATA\Programs\Python","$env:LOCALAPPDATA\Python")){
  if(Test-Path -LiteralPath $base){Get-ChildItem -LiteralPath $base -Filter python.exe -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {$paths.Add($_.FullName)}}
 }
 foreach($p in $paths){try{$v=& $p -c 'import sys;print(sys.executable if sys.version_info >= (3,11) else "")' 2>$null;if($LASTEXITCODE -eq 0 -and $v){return [string]$v}}catch{}}
 return $null
}
function Find-FFmpeg {
 $paths=New-Object 'System.Collections.Generic.List[string]'
 $packages=Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
 if(Test-Path -LiteralPath $packages){Get-ChildItem -LiteralPath $packages -Directory -Filter 'Gyan.FFmpeg_*' | ForEach-Object {Get-ChildItem -LiteralPath $_.FullName -Filter ffmpeg.exe -File -Recurse | ForEach-Object {$paths.Add($_.FullName)}}}
 $c=Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
 if($c){$paths.Add($c.Source)}
 foreach($p in $paths){try{
  $probe=Join-Path (Split-Path $p) 'ffprobe.exe'
  if(!(Test-Path -LiteralPath $probe)){continue}
  & $p -version 2>$null | Out-Null;$ok=$LASTEXITCODE -eq 0
  & $probe -version 2>$null | Out-Null
  if($ok -and $LASTEXITCODE -eq 0){return @{ffmpeg=$p;ffprobe=$probe}}
 }catch{}}
 return $null
}
try {
 # whoami is authoritative for the task identity; paths come from Windows' profile APIs.
 $account=(& whoami.exe).Trim()
 if($LASTEXITCODE -ne 0){throw 'No se pudo identificar al usuario con whoami.'}
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();$sid=$identity.User.Value
 if($account -ne $identity.Name.ToLowerInvariant()){throw 'La identidad de whoami no coincide con la cuenta de Windows.'}
 Write-Host "Cuenta: $account ($sid)"
 $server=[Uri]$ServerUrl
 if(!$server.IsAbsoluteUri -or $server.Scheme -ne 'https' -or $server.UserInfo -or $server.Query -or $server.Fragment){throw 'Usa una URL HTTPS sin credenciales ni parametros.'}
 $ServerUrl=$server.AbsoluteUri.TrimEnd('/')+'/'
 $InstallDir=[IO.Path]::GetFullPath($InstallDir)
 if($InstallDir -match '[%\r\n"]' -or $TaskName -match '[\\/\r\n"]'){throw 'Ruta o nombre de tarea no valido.'}
 $task=Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
 if($task){
  $expected=Join-Path $InstallDir 'Ejecutar-worker.ps1'
  $sameOwner=$task.Principal.UserId -eq $sid -or $task.Principal.UserId -eq $account
  $sameAction=@($task.Actions | Where-Object {$_.Arguments -like "*$expected*"}).Count -gt 0
  if(!$sameOwner -or !$sameAction){throw "Ya existe '$TaskName' con otra configuracion. No se modifico. Usa otro -TaskName o la carpeta correcta con -InstallDir."}
  if($task.State -eq 'Running'){throw 'Pausa el worker con Pausar-worker.cmd y espera que termine antes de reinstalar.'}
 }
 $cfgPath=Join-Path $InstallDir 'config.json'
 if(Test-Path -LiteralPath $cfgPath){$cfg=Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json;if($cfg.server_url.TrimEnd('/') -ne $ServerUrl.TrimEnd('/')){throw 'La carpeta pertenece a otro servidor; usa otra carpeta.'}}
 if(!$ConfigureOnly){
  $script:wingetPath=Ensure-Winget
  Write-Host '[2/6] Preparando Python y FFmpeg para tu usuario...'
  $python=Find-Python
  if(!$python){Install-Package 'Python.Python.3.13';$python=Find-Python}
  if(!$python){throw 'Python no se encontro. Abre de nuevo el instalador para actualizar el entorno.'}
  $ff=Find-FFmpeg
  if(!$ff){Install-Package 'Gyan.FFmpeg';$ff=Find-FFmpeg}
  if(!$ff){throw 'No se encontraron FFmpeg y FFprobe despues de instalar Gyan.FFmpeg.'}
 }
 Write-Host '[3/6] Preparando el worker...'
 New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
 $private=Join-Path $InstallDir 'private';New-Item -ItemType Directory -Force -Path $private | Out-Null
 & icacls.exe $private /inheritance:r /grant:r "*$($sid):(OI)(CI)F" '*S-1-5-18:(OI)(CI)F' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'No se pudieron proteger las credenciales.'}
 $venv=Join-Path $InstallDir '.venv\Scripts\python.exe'
 if($ConfigureOnly){if(!(Test-Path -LiteralPath $venv)){throw 'Ejecuta primero el instalador sin -ConfigureOnly.'}}
 elseif(!(Test-Path -LiteralPath $venv)){
  & $python -m venv (Join-Path $InstallDir '.venv')
  if($LASTEXITCODE -ne 0){throw 'No se pudo crear el entorno Python.'}
 }
 $stream=New-Object IO.MemoryStream(,[Convert]::FromBase64String('H4sIAAAAAAAC/719WXPqSrPlX7lxXm9HBwJjm464DwYbLCabSYBeOhCyQSCGswEz3Pj+e6+VVRoR3t7nftEPO7YBDaWqrBxWrkz991+T2cd6/7+357/+z3/891/uZD/BH3+Znul1RlZuUrMObs1fjEdd366U+9Na9TxdlQrNgV00a11/mt/nnMLTzM2XzpO8dW565c7HqLtx8nezaaG7dGq+93Yuf7mj7trJ+wf7XDatarczwHfO6lRs4j7mLNew1/Uvp1f+HOVtw321zrZV+jRr/n5aK53dSnnurIpfbq2amwxLh+kx15gMjaNTqOdMjMculOfTddt/7my3zqj8NV13ZpNa9TKpnbbjWfzY7QXjaldW4XV3Tt5dT4bFNc5d4bn2Zu30ZefdrbOaHnCNg107+dN1axZeo1rX4yiuuyt/Zw/mGFt3Z4/M+HW/OEb9TMcx5wPzEHueDr+Lj3dasLzpa/1rnLcuied7bReTn7ub6cqa2zXMZfL7rTMcxMdgTFen3WRoHuxR/ewUzMzfZD3z2efhPid3aF3cp/h93K/pau9PE/Na/LJr1qcztHLTlb/gePFsw65V7/cGpTfzOTczFy+HVuXuxLUeVOt1a1kddHtPpfB6XrHXz5UGZuVxZq7L58nInru1gYfrlC2ra/IasfO+zEp9buchmxVjDtnaNFeytjy+1c9NZ++9aG2bK9d3X2RdcZ+ZNxV5wTrm7WJzVV3bw2LO9JbtCsY2zp/m00Jr1l+Vevawu8UcLNzK/HpOKkUlxytrORnV/XGha46HRci7dW70N+2K9zQzK+WlPRzPptExn9H584s9PK2alae/x6P6eno+zhre9pebpzy3tm8Yi1nhNeQ65/HQv9i9cs/FWDHvflet6cZcWjvICGTU3tpYP/O17kM2zpOhuz0+tGZO7WU2rWEfD9v43D5gLy6cvHGcri1/vHqR3y2r3jJrbexHXKNg4V7dOfbl9rmD51i1d+NR+2K+VI+TgcW9f25U64azprxZVc7j1Fve41gZK+RgZVZLn5j3rYv/GxibUxvvzJrhTwttrNmA481B/o3pOTpP/r22jSnnr7I8jIwS9qCfGxmPG9znMs1jnXpLPa/q3zRv7WyveOF+dEctrnnwt6yljKVWn+O4T3dU3+G64f3cVXXnDgc8pwAZ/oX9e5B9VS39Pc2XDo0suVzpOToX5RjT8x1zLXPvT/0SZOTojXrFM/Qe5PdpY3qPXqP39MusmF9msJ6vSlfZFcq+dXaoo7widEQd61uknF2m+A7ykR8PT0b0zOWt7ZXVccPOYZpvb2zIgVl5KWEvbNzX7nF6NmeQiZna09ayubYu2PuHMY8T2Qjuzfu1L9TZNnVV/LojC8+zTF5nZUMm3D33yQ25HMpYA/mo1KtOJZzXmZJ535+uBjPI79ysWr1+JbQDl8nwbjYuUG6twzjvz7GHLtApWxnv7m2u9ErpomVSrf3KwjrXD+arPXdeLV/JKmyUh3Nqy8142BZb0azw2XzoguryfVDE+kH+KhvIY9Vwa7MS9vnB7h1nLu3FxXhz8kUf56wmw5PvrKp7ux9+t4TMzsNriL61YNc6pfblKdqvr1UDc16kvvo41+fY81vqpTeMS/1dLAXPMIFuUPfdJOVa1oCy1YXs7iBTlBX+vXfMlb80/VxcJmJjvXGdVRFzOFDXqdlbh/MMmQj3AvYGxzteVS+wu5TjjZJb7J2a/4l1uUwK3a9ptRTtldr8+A55a5yvbMmB14OsQM90/Yaej0ZHz09t7kO/iE3F3nswl9UFbN7RrZj3cr/XMq7Vhu73vxyvpPfZcWb6lGVz3xm6vrPuYD6fvEGgx3N20Qr8DzWm0PZ8hvf1V3rNkzon/H6esZef5hijh73ij6AXncospZf1PK+qWzz3zBKdEujEmdePdCvmv059/AB5hV5rG9S7dm0wc6CH3dXjDLYjZ0OH8TvMXX4yrJ7hi8xx7hl2COvb3o6Hx4PYqdgawz+DL4B9d4buqHVpMzeQuzJtItZq+7FSPpO5wDMvYYNgh6aYO7Oym43p31V3nlsr/bKHd3hezvNsP8iN98F88rzguNB2VUtbu1J3P5O6CTq9/SulH6Cjqkus/2V4ro+bVrvWHJx8zidkmOsv5+A3yAtkr1d343sj2MOQTeq4i0PblB94qXt4kDPZb7KXw/W2dryGDXsw7pW303P54BQ66pjUPgnn0Nh5HcibWxO/YvAxKutxPkEGykdH+cHcz19Ovo316uyp6zH2vXljTHL/2JggJyn5C/ZD2zGXsC/rLuV7b736R86H+E6r6pE2YZxXa9nMB75O/DqhfeW8LrGHcg3oz4/h6Ws87Ig+/yjkthmyv1B7rbx1PNgs2vuhv5c9t5pTXnJj2EXsz0zZD22zJfKh1wj6W63vgTpglDd897W+HRdasFtF7PE2ZLOzCXVCas4ma8yDV1y68C+n5/nehq2C/fEbvSL3AXzNQXQu/B3Rc1hb3C/LT+vZI+ogzgf38FGtSd+Q+zVjMvo+DHWT+CvQCV/2c87r5qyB6YmMB/p89t7HumCc0HULu2diz54gv9BJL6W+VYnsFJ67mLaZNn2f1Z3oXcYFzXX4DIfx2oJ+7n46hTKeFb7QS/Er8jExZ73lQX7z5ufgufAM4hNi7nPvo9AuhWOwR/OFPSrnYv6Gr3SU8mG1L4l9Dv2j/k75Zd3zR2rPKPnpYo6qW4e+jIqtDk6tNLdfWxt9HeVTVWZ3rf7yzLHDZ8/BP9D3N2GL630nT9n2cy7klP424q57+qBpXRc+x4t1JzaDcrv4zbiUL0I/CDq1S18H+7W9GY9+Pe/O5R10wxHrgfuvn3fpPfVan0+oq+K+b23s9ardwaBSfgiecZwvQX5y9+brHv9357DHJe6fxO+95UzHg+JPxPwVxFCQzXAfHul3FWUenwPf4+nvxmpfUHFCzIfFnE0qt/2d1HmyvtyjiPMOV3oI+4hxN/SA2NzmSvTGJnb8NjZmXL/9a1QI47RNLObpDJb+sGN1q82V8YuxSKNm3WEec6N86de71T3D797G9bwDvSD+C/wT6lqx78k9Mx/nsdcYp0E/JGLlcxHyApkxSsQYjpD7DexJYYL5c4ZLsWnQ53fuszFgzAMdcqEumsKWp2OPMeJOPBf2IfTU2jo0YPPoiyAmvHA9qesb1XKvZ9ll62Wwxfx6TWAauD/moQscoO2/rU1Pfe+eadPV59j4YXdhUzf93HLbeGnXG4OxHN/wW/tWL2c0+y93bx7cjt5y08ExXa/u4nz1jBf1DPiMOKcrvmdqLl66lv1mDU6txnc2J3oGyOZ87+Q7m1btsdB6foqv8RF24NwI9WsXMV1nxziRsb5N7KMXyaKSceqB+O9F2sblqND1P147G+0TElspmWsrZ3u5u+aojXjK3DbXbWIHR8RocZ8CfsHdJtg/JnRu66JiHMxtsVFDfLsqAX/wD4ixjq2+eWk/D/Lty6w4HkIvM/6DfyzHn2nfysonTfvJN/y3zuPbBfK7ds6I43tl6I/iwh2e5lpXQHaL+eN9dUe9Eo9NsHcpj0c8T564WeyZFsQCbInhq7vpmX494i/odWAe0DUiKw/mOjHnjB1CXT/K+9zXnpoT+MxqvkvRemt/EfE5YjL6XaL78E9iYG2XEz5tpE+0D712Kc+w26LTNx3LGvRgN4MYDXoKMVdrG629vea+jM6v045+Kjs+D2OGwbL0blUEu8E6FBG3AGOTY8zEtRC3Hmmj7d6cxx1srdtGBcEN/PdeXWQT8Wqwt/zpq2Are6cg4/4ar1sl67Uej5/Dcbjwi6ET/mR8lHtEwdE6Kr+GsRTinWERMlD8FVtnrj18yBn8gRawBv8wLlg72rS3wPdOzCV8P+w5HLdA/KXidaxT4ww94pWftcwsKDNmzTWgz5diH3G+jhEQB5Vh84D1QLcB21iOe3ceZQJ4mGBQwIYKjtbp4s9XdMx7pj8EPwl7SPu2kZ8HvQk8BnbJWopfBrltBHFo4PtYJQ94rz89191GItYCXlt5OprPtIPzI9cQ6zV7x3XafXxf2cxa/adzu7L5u7X42X7sQvfRP0YMy5hyTjsP27473ht7yit82aUzhE1M7UcbdtskLlSz9tNXYMPAG3AP+CKDTesKg7rh67x2iftKnNx6uvaDqSe4P2WeAuwZ2NSk9nJu98cpX/fpyn7HfMkQm0is08WQWKnRw/Fn6oP2ETJ6IXaRWj/tH848N296+vjANiafNfZvonDKwNYfYnElnqv7OQ7iomopx7gIsi76+Do2KVFectDrOfp+Ts+8ec+Ej1VVOE6Ea0KuaXsKZdF7Y8YSgl1Sd1rAbMpc+/l01d7AB/kSmWAMreU++17uhlgJ9ssGe/aX+bwp6Xsg7mr7Sm/BFopcPv1tPr8cW4tOZtwT802Q/4Dtrzz9Iuas7NXccFa77bfPzT0SytRdfI98P1/f424tzNMKewZrNVD+8pD7ghgxxjh8fd4NHykvCwdYzTi1T7LHWUI+pmwgjipAp4lOnrxah8l5eb1HMvZDXJffPC8+F8Qz43qHuGWtu0XcwFgOccUcsa3LWIkY1TyGIQSx5+c0P5+3FoM8dOjNufwOs7FDPVP8on2diO7lZ9oC+F6859CYHx+q+P1xNsjNy82+abS9bNkLsMpk7K1jmEq5DIxN3T8rltH748a51Y+a2D7u+4xnVTErsGHfYdxEHOXZ/N2cZOk+5pagF06+DVy7pXMl4l9J3FAvIhYQP+Y3uOvfk4KLPeteYvGC8s9GXci+wWein0bfGXj/7JL21a7j6acUHnx7HKl46EZsGcV60MPAoQe35tWnz6ryGAo7aT8/HZvPnWOrd8y1nls7fC7i8+nKxvxkzhU2E9os4g2tLPmI64MknuIr2ejMGsAktF7dZWAA1mB5usrj/DtlCLYJsV3xAtzZR9x1pu1vxJ4Nfs6p0UvIlOH4JWXvlC3cKfx7F/NNwnzl2b7yO/Bdrwg9eNo5Q2A9+dlm6tWdcc9YtSq54mi0u7TWOfqOge4QPPOncUFP+9eIcRZjhSkwPsgRWyXW6Kyd583whHzcYwyvZcxWOjaZcy4oPwH4ksRHkqNcWnnaL9jVXSLHey5W3RXxyMhPV3mtODaXxqXLiH8ZfynMc0rsHvobMgKHcJBpz27tK52zUjFKEg/81k9JYFL9FyNLL/7Znov8FMpSkPOjL9dI7blGf/OtbUJ8RluCuKizuekrJLG6jP35Ux2s/vVfSq+Iq6D7iox/N4L1roCLTN8ugr2uiTtC7kfYb7RBr5bgB1hDYlRKtvq7GeWRfjhlZTxqPm96gmdJ3nSMGCYmb7nJq/gzgrOrvyX2Plha7sSXZ2782SAGenZrzA8wxu/OoYuBrWnMJMRatVxWZP7PcZnEmOBfdi+JONCvv/eNzqyJOGYisb/B+3vpc36CEwGTwjrAT1RxiLoXcrKNZF5MxUwrxMrA0uJzgZxmcm1eTu/dM9fC/oLfNFB798mfXjYKg0S+xmY+/4zvzmUd45i7VB4u+vxdPKRkaekUXIWPVuaKs6D1D/EcndvIwOdP3HsHzAv8GmKnmTr6j/gBiEWBeTaJfxJjmMszYF3fzuJjX8S3xvFavuhnM94wHByX1Gkx2UaMa68eN6avrmVWrMub4C3IZUFniM8OX6nOPZuvH7+fyzowRckhbNMYJfCunVtJ8EbCnEAgI5hPR8Wq5hZxgWC+ghFdXd9wiaWEuIHKHSZsQpP+yLqzEd2G/BDWYO0MJQ5Cvpx7uCvjTK21wusKkuMM5g7PyZx9+xdlIyMPc/iAj0w/dkxeDfAJ2J+c5IDoE0dyNoeO2EHOzsRCKPMqvlW6ELGHP87vL5k6MIy10vwNxNbD44z5QnJqxO+FPoP8+wpfsEXHKAwCugmxJ+NvW7glvHdSxq5iin+LHOt4EHrFBW/lA+NwkDdljHG8f1G5QmDRV/dO+afmygBO668kVgemi1yp5M8hj/ehfAH3Ffxy1PJGo9z38Xhy3cWXVVj2kbkxyT06XlwGJP9OmTkQs3BGrU3mWilfhnl7lWvCuLFXKe/7VmFwZ972BXWMXDTsDNsmeLuyf9upUVI2sP8bv/LfuR5aF5JLQV0e49mM+ka9SZ1OHAK+Wy7Yg/xOzeky4OhoHTvb3vBXJQ5XuV+FU8haIEc5Xvs5Wdee8F6AhbU3KgeHnJDEcHMZG/IEWbHmnvkd7lGN63ijfzR33C9a1ohZnSWfAgyhDH/S8OgT3Jg3+iPnD6ukckYVJbuUY5HNZyNhV5ALpM+8i3M+3ociU2LjgReW9Bwl/fWVYNrzAPdjbAUeyedU5GZG7Bm+98knP4/4K+/5Pkz46aUAWxTffwgM4Tl3elP5hTgeE6y9whasb7hXxMTp77+2PLH7lfqZPgrGgFw1uCqZfoDKkzd6ss9lToifm4ttSsfXf2G/xL9Xn2mTVIznY795Stat86gArKrmLxUn1tzFeCPkbG3tWsC52IafbeZOiL/mq7sReGvgE8B+dKkLuV+X1D8xuQdnDrgauFfAvH1ib8ipUhdt/9iHgY7+QO5Cj2PJfCd1VMidORu1j96VLU7pb7GhmkdGO5qhJzPtDWSjNiN/YhP5hO77YLmDTxjXiWrN8J3co8G80Qi29dWO5U5SurES4fZWrtTrnYHbx8bFvMlI6QvIwCkPLGGrxi5jEq4Sfejp5eb+Fd4u8Cv4bMjxgYcA23VhrJbln2bmpj3BXv0sbEf5TCFul1g7+EhXsSk+63h9+TM8RO9VGzGsw32sbF2Qd78nB3PqzfVn33lbtI6tqlH6k/3c7v3D/Dx5fYVWVqwdYkIT6qnaKc2dUDE09pt7lb8NY5O/yTNvxPh5rf44nevVWHsROO0J+2cHjqkPHgt8WOSRgzxrPH9COZpI3N8Bt724AC+wNhbORzwHms6DYZwcB/GuZF5T4nIePyRHMDt/Fdiohb1yHcU9LfqaQ/hJv536V3HU4MOC78A8kXkjlzJYS65pH8OKh0E+03xdMmeBPQPeaU38O8adIX8zzk0jr5ccTfBsEtix8o0SfrnK/SZyiOEckJt9M1aEfwJ8zkwc+yMuQcDX9zCO2zz9jbp+nENexD2m3HP78WheEd/ikju1ns1cYyE5gB15xPCrjemLyuO/98kRsoTbwXsgJ4n9Mt6/VRJ54LUtNQ9F5lu341zAH55jHLbvPBsRR33pv3WXj7hmME7wkaz9JuCUj3q7zTAf1SYMNO+sFz7zbAt5oWxdPkbgL6D2gvwTnf+fDY3ctin+aR3P2AE/ZUDfZ6GwOR+x9ADzQgzqpHQw1rvei3GvoJNCXzdpd0aBnASygTgP+gVzE2Fi2DsGdH0fuBhkGPaYeUqJN2CTOLeT1Us8rlyYLy/kd5OXTDmf9Y2WyqufmVtVWBl0a87NP8b3JvXezpG8VVnVc4Q+qtSeiExj/6PuQnyvA3UZcO1iM8QVaaN3KZsVyeZY8U8PaizgLaxKR/qa5url1zi2H6LaCOPirtpn9ylxfWDplj85z4AXm0kujPAZ1DHwv3bXnFPFvQly9I2a6bXIzcurc+zVCc8zi3Ct1P1iWM5VntMZtfPIS+eE+5PfC06lnrOoOcaPG/pS4XHLU3OUK1b6L+1m8/klwxaGuHOK86jGBF7NF2QzzQP8jd8c6JdyEXIFe98XjGLCOo2RyBdwFmAA3rccvAAfFT2fZT//nZyGVGwS6n6pS6E/PWzLfI3ACXCGJfGDnXwdnKPl93hiiLmEc4L9Yl2ISavaLJ2zitUsfJfvy8xTVW7gZ8nzgrwx8Y4gNmGOceuIbwmOMX2dPH0i895aWr1Bzn/ve0fEElVwOaALaszbIy5ebB9MwXOsBX3u8bC6aA5PC/gvnuAh0ENvmN/pmr53fB1QF2S1tp+Z8Xros5xblVt5S1mbWF6deW/ychQH/3eYMvli4Dnx2JBfEc2LFePyf583FR0g/sX390tw9m7i9sm8XTvr3ll5yG/81th8sc7qwHolR3TrzNN+a6afms6d6dxTVLuDGB3Y/UnyvZX5rd8vxMlQO7OWmoTQZ0EMXWitde5nKznaVzPgoG5/u3a3cnBa9qmD4MsBU7COjefW8ftcxs/8/+/mcYB9BNnZKi54V2pgNM8nyhkswjjhd/OdGn8sF0NcALG+87rM1M+hzejvwXO3F9PA7olPM1d2SOFZwI1n22Zg6yrFVs8oWf3l6bl3Pp5wvj62zdyXiunC+iwDfNm7OH9U1SKNzJLkaXVNSQd/u8wnrbsd/fuGMgA7tNW5lxJqSdaKAyL5OOi/Nm0kdKMv+tCstnltyMR0310vI3+G3M+FEdwX/k+XcTf5oFIvBT643Av6Q7AP5BQPjPt1XRN5aGmu2fEdsS1yrPCF4NerOir63MJbg15/QD5OfhuHzwVd4+X2EW898/o3z1N8QEPjQSfh6LxbEuv+k3HCrwZu0t8fkUtZAm9jnsgQ3Bv2qtlDboi5GO8U8OFLxEmgi8EpFJ88ObdZ8wA7Ba5TLH7AWl+iNdDHfqpc/ew7Wy75aXIKmoyRhsR3O6WAI2jeiD/BtdyoaxcjHr3UErcUX9sqyVymfBPgMoLVB8cpWWBOfM24ue1n3o/cwYvxozrD5vlHfoSOCXXtVLWksTBwGlclj/mF9wH5VCneSOVPeJCPnuBOK38d4GjNBAcyMZ9nybfEYgGsH/xQYpt3s0Fe4suijgkkJ8T4Ruc+ffJy4XdcHMEXYM+G5LJJ7mkueVHFvyW3XmoiqA+uagMYi/f/v8w95Q3zPw1qGTI5qhjfPM5TVTwmsU9Szwzf7aL5o/8Mf/djdWRDciyrxgS15LSPktuiviNuhbpf5IXlGBW7dP3mP5UpFW9nrP/PcNyM+d3RD77BmQrxFr1PRefEeO2B39K0Rz5qebAnX3w++xm+2NF9TuMgmh/0/BTovpAf09W2WzBb4R8ojCSlZzSnd57wLZqCrQ/Aw/cv5AMJZzIlm9G9X4J7hzVA5JKyDwBkCr0PiM1bn6ML9IlfQj09/Gf8H+mUUB76H8Rohga4B+B0BDZUODT/9V9//a//+Gs3n+SL9+zk8FgsfRj395PH3Md90SkW7qf3bq74YTxM7+/zD4+uO81/PBQfi27uPpefOA+PRrFg3OWnD46T+3x4/PzrX7jccfNr+fErq0lEEkgOExk6KWudkVQWQFGR3tsqqfCqAx0ABCTikoDJJghQrnlbkzqCQHv6ujzwPhWoHiefm6EwfOXK5GGiSLzSDRQAlBwcAcXgeK1bjVhDAxoHZVhiDRdguIogTVxix4XJoNh3IsjJxg66UYQAyXMWm8WaQ4jBjTVLAHlj1BXQJXaNc3wcICsiWPF3sd+RBECCfFVaEHyJfw9gJ93wIfbZMgB6NyoarEAgJk0mGijCF5AeDTVSwHoIglc0KI9zYgkXbt6dh+uhUMTqS0HzpXVGwjz3huCmTVDseZnH51NrAaD4+SXfwvcs9MJ3SI7ZpQpwiIAkGAueBVgHOUCNr79p3C5A6l4aAWCvFDcCwDkEPgt4M6Awpkj2LBvATAS0TRm4xH3hOAcF9veR40nAn/IioOB+gmKVqZxXp+K8aAVI4O8KhAyIJrZajzmL6N97wTVdjGP+qZKYahxNVZStElXr7n4KECfjGqGRliKmylzPTZdEIcyNIk0LSWElyrLUYuHZEIETxjzKVy8A5LaBM0DwJqsIB8YqAIV8kctV9fwhsgL5HeI8tQbbaD0TwHYwfzSKivAQA36/A0higHjcoN4ExElmh3OXBE8wHw7BH+57vyQBIx1L3RghNMBvs83vSec/MqpVMRY0qq7sHxgMrc9QYHcI51IcRTpMGkhAAv+jWhJAE4kN36mGII8qbAr2wW8aKyjCDg0I5bS60E4UHGxjS6BUGiwwUGRCcq2afqiAjsUjquEHwJj7ZnL+BZRq9Z4e33uK8KKTEyt7ZQDgdD8DsqIQm+S4p7sfzSmuAJnykVgJSGgyj+PVQBINyjkBmIvPrV4ZBcCzaA4jnUD5iPZ1rfTlVOYKqA71h+jji05YR05eNQJv5bzXVlr+ZD9KgxkmDCpqf06NvVw/mUScX1QhcxhIpYmnem8nnLvfryuKSvsx8gQSHQIcIYFLkPJB9MYoh6Aq3fxCknhyT/zW0IV7DN42QVMZJiFiOi9Gyhwfw7HVbOxzlZDhHiQZG9dN2CESpTpLq9U33M/+stTrD6qtkYFCwgGSr1YXw2u3Ola7z0QjQDa9JtR7MxlDCJSvXY8yL8WoOomRkqMYySujKFMFX9JEhgRZCWBjx3RfrGHfxzgrR9WASoqig2KUY+P7woqEQ8wiS+whM11k2bdeuu+W1Uk0AQlBxsof3YMFgcpnWak1eB+q/0kKnDAB8BwmGiNZC+eoqB1J1WwjOY8sRD7qRkjTK+LM8Jy7Q8Hn8Q1EJCkIYWFkJUxi7QInGIkwEuRASKuyOGn7o+Qi5JmEsmDOQHCB3a7vJ8MHkg4XLKAfR8WVDwHxgSC77HflO5Ygtw9SyP2aIfts1HUOkoz1IvUzbFGoI+TeK5ACuaefN3pvX+0H2Ic2AsNOqQsgjEXOwRyq/cNEIhqc5Us7km1skbM6gzsUM5h7VxWwx4rZzb00JUIwyEBQZE5AOiSO+psjSA6xNWTh4h7k24R+ECADBYK4785rjrTfJAnYOv0VKUSG1/0LzbSO7V5wz/mXi4JT9SxdHnNLBnFNNl9wP5XO9RWpVeykmgfY3cuoIL6lNwoSOiq4/mac6prBflbXDMcVJB3D6+m5ZcGUY3rGl63mMWz2IoXW2ucYXa17stFAQieITCQA/wt0UeS3oKkD7DQJVEi6mpFuFv2NBkPaJ1OFbSjWXmwyGzeoRiNB0l83DBvSV6kXB4xBXiGLtbaAcNQXsBkG4g2cG8mXKsQmyAR5eW1/UvcOAf4STLULsEckdekYBcDWJ/YHdMSURecbUxVyEvxduGwUAr9jbJTgt2BcZ99lgenweJWs2SCRVcw8J6+urYk+kIOlItY/3SgMW+tiLWkSUoVc+tBZtFWBLLkEAqNj4FPbAubZbI4wH6+EtHZDRutCGHZR7Jq8hr1F0sfAHkhfB2OAb8x5Q2wJnzc+nkh+9LpIo5j0WoX2KijoKbKB0VqRl6L5QgLrHnK1akQNzOK+XrDehYkk7Y8HJg7hm+5QtH7oMkELHZO+d3c020TrXC9CzuPX36Zto/aH4FvheQlGqAQJ9C/8T+hc+DmKuOBtaLNPV3rzRYqxQj0Jwi58Z/qWV348gNiuEChoLyLgQsWt0rwpIsfNVAF7nYQ41bznJz66auwTA8kUWYENAJV/y/WEX0W/OSz4BtnlFcnCmmpqpIAX5etSLwBL2E1IarV2x1G2vQ/PBxHvjsRmjAf7bsBCeyFPIMYkST6nZEjkN4zj5Z5IxrjcK6vcIfY3k+OZ96PNIfYBnz/0p3CtC6/F5hdjFLmOdIMIKQACAA/f8xPkEU+O0TIzAvljDKJHM3Nf1oFLWL46RsjMvB6KPFDsysLgShFNZNi0w1KEDuUXb9nczYbOS8nN+dazBKCwK8QMldBVcc5R9ILDZhkY80fBKKXJPrFYUH03i4gy2DdBvA1gzmeTqRgRK17IrXS06KdKEJ9MRS7slc359ShbiX0TFrHSpwT53Zs7iRiCa+wZCpQmCEjiJ20J9DpIiStzrWKBz150DPEJNq5IAX2CxSBuEp+BsdJQgXrSyIm+6PQVxdHw01XCBkXakKtmfxYl8tC4QJFd2WgCiRQUO0lDwBqJatRVvtOqxpofERtic64C/Qk04QwbxkW/ofGMbyubx9/+kzpNgb0syPH3LmUtfkyakHLrPtmxTQZxgzGhNCygX4nnQdyKQmRibYz7nOnbnuPQBd6wiS5spSQPQr8vheXcJAajkcLXmAVvXjHyJ/S6XMdP+twnxk5Bo0sVK/eZ6LwE/oHEVQBoLQGY2ZRSNZ8MdOZTVjObedTM5o8Kdi6M4zFHTAQGyUySngQ7CJqPxGJFafbJ4hokV0ZiewruJYrvn24QkhKESDbpPKimLWyaNE/hgALiSxIXvm/YYGDc23thrK5jJmlqulKNMUKSE/XJVUGIxMuJ4yPC09V8JY8TWQCBzTOPyfsnGoNKAg/n7JCY24Q2/ptxNq4bQVw3PMsgSaXuFyXEQSgMEuf9lz3i5nqrk9sRK91mE2cjwtR1kiW+Roj34K+S1PwnRT5DFGl8k4iLsPswIRftv5T/IfNXmSWbvuI5kk1fK9ug2DuRsA2w72AuM5q6qrlks9LhbtNKrl0WGSGxnjJHw+KX2NJsUgKwptvyEBHTQkzlqsgsFkNKIRaJ247YrT2JGyRsE99jAx9Nti4/at+LvlPQVBT3VY1VY0T/eybusDeujo/iFdpbwUfiOGzgw/p2XogSseICNmZSyauM+6nmH1mFbXgevU/l/oF/prHBrGuR4JRuAnNGE5jSjXERR0T+4EfY54sb13/UkcGYoftizZjmWdimJo9J8yjuTzS2kiJAYJn/aT7Hvye5fK7WFP63akhxkoZ7+jt1rNjFxLHS3EYT0eQY5EiiBlX6fj/CTJeQaTabRENDZyWEbBQGgeSLv6PiG9VAlM1m+LdLW3ZmAZEq9MCz7nhfyLLBOTGfxxjHHr5vK46vqkJIYqYgOjI3F85LRuFtWGBJmwv/xiW+wmbHwDtSeZBo3oNz4pioIrYHRa8Hic2g95lAhSyhaSlkPiS+AzevKR8luBYaSsLHZWFYoolQ408bpKiCNTRoYr4RBQEghebhg2gs3Wdh1lfQlHqsCmFjzYbwL2qqksT9f+hzv1d+44f1wiY0fzcWrfsfEvvfMG7gv0s2yluRAKBJUb7y3UiGQgMI3EcKMSBTIanfU/Km8hovsWdC/sVn01dp9Kj/ljU0QCxio2nmHhm7sHHQ3fXeg05ew7YjUe2i+Q4Kc71h/mX/sXzZDxdP+zfrcY+mDKcmZPRTGiAF91je/8OGDIEtSzdjUM9TlXznwRnulyQC0W6x2Rp82hSu32WBNElyQSPaWaMaFjAF+n0b3w+NmO+cbswU5FtFp+gxxAuUfqYbdFN6+K0TaeYz4N4HFlL92znfeF6Nw9OnxX5o0Y9rpOb2qolUxtwEGGliTVQhisIDWMiF2I+EkaBRXVCowsZnCpOlvRacKGroqwmbwf6WeCwo0ma8Lbq7XUoUPiXjgSX9YRYNqZhUYkyNMxTjuCLHcjV+RSaWJttCmAVGSC4BbKC/SPmNQoTOKEgjEVvyvSr+nAfPtruSIfGpgwIkQx8fjPHalwVRbsl1lrwcCi5od13JoxksYI9iwRSJGHOxcsLcI/EJQzXteN2XGr3U91XddM5TuB8KxTbIk6mYmoVfFVkv2uwFcdzPDL/4+7wq/UFrQd0j+iWpbxnfzF02p2C+CvOocpinreQ6Rc9if0F20BRjoe1/5lxJ04yRbtALPU+MGPZZ5i3AooghsCmMFMShIXL4fXSup+2THlMwV8Rv9Rp6ygdI+qVPyZj5+Yn6fRnhJJJbvbJp0X2LMb+o7l7HQL9pjicNQ4J8r26Sp/Q+7R3tF+c5tF/TtG8fkdtU/lfJXUhyY3EVsUzB9lHIq/ymmcyDkP9qqulGMJ8g/4mfgqKGuSoUfjqCmwG7/nR666NZ5/PT/W9Ib2nb/TyWokDm4R/ZTJcYnWqMrp5tL8RZ5uLPf/TMqYYLoa+s1l+aPiSfZdTLijkTxwh+mryuKs5Kf6caR6FJ1PMT5rUjObkGfY1X+lydHPyb47W+UU0tBHu95VvG/jUydJDt1R+UXjVUTK/1fcb8qFwP8xPUifljlNNnARRzSoi1mGuF7lDNb4fzLZvAwiZRZs4qZyXFbqrwrZLMm31b6OAZEW8gyA0x/jFYfGxjzq018gSq+FPFH5J7mkjhieTHw+YqMraRfQjzcFeNERJxAZsRn27NaSqHhfzWkzx763k7f1s8hRhagjyMNb25rxVuLc3mh5ene+YLR+CWCPYH4jlzOurZE7HIVhoKe+YBNheyNF+Z/n7+kfdLIzYlF7x0mWh4mXzG5fbGHkzm94bw28ENQoG7vDwG17hTa8Exd90b15BmGJNevKHbXBoz6Fhs27hlRzLHgAYYkpcew3esPkxGhpu1jql1WbytXlT+FYVEWg5pcwVfiP82Qszv6rxlyHW5bOdyzuJFy7W+xsIMPp+jfGWyMUvDyigSUeuxU/tVYdjQ0STWq3OCdbk1LyrPOWtcsBfzaBw9NCEnW8yFNDMjTi3X+RzusuTvaj7BR9q7I9pH5G7RcBg681NyXCqvLPkAPWcr/UKAXZDbRYPTME/cfNp8z6MQ3+4aX9C4O3wNNIUB3o2XFYivKfk2lUvMozn1b64v+mY3ZZ65Vl3rfLbw4aYqJ6jvqbAK2tbsZivJGF/s1M/2vhp/9HzRC1kiHZThn6JsD68+Iy+J547Og2Mr3zkQx278iKcCOQVPL+QZWKVQB+G3SB+sXu6pD5oqb3L/UaiXULgak0XzthxCl/62CE2vbyp+kOeqj8Ze8EIvclCcfttggfSf6sZ/y3xDb3wU1HMNL2WXe0T74uCmPfqt5zbiWNqY/8kzR3sQLxM5jsS2SixCnYN8aO7iIteTpRtUbMJCQZ1T1S8eifE1vQzifaJRd9Ya6JgnamStcst+hp1P8MayrhXYW537Uk2x6R8F3Chy/DS/LBMTTBL80YSpTv8N4498a8EqdY7623MKiMW+OVY3wlJxXXWfseeDhkpPog/NnDW2XnIXS+m+RdeaD5rWbB8Wqy42mnuTpT/+zB+LdJ3k0b+TVdmrso6Mf866+dON6yqOsDSV37Hp6UQa8CoOkeYPaxwb8Sp4XUHusXGrsDfaY1Eco17c5NjMf2Ajf6ARtOiS15n2MwR/h95FYSGwUdNrV4fVbr2/HN834CKjQYfbOC+F06HG5N/yH2I6W9bwTs/znW7mxpcK6Hx/lw3Yhdem8LcZ6wGWGru+U41a67lpQXAQcGtamXvwOjel8e2EfEpsqPyY7PmJY8axZ1Axo5qPzn5YMar9ZbfVs9p8uYzgZJw/9bKKb/2ib4qCYONpx+Fb9F5OfYX/BnjxY2bMHGtAhyIfcj5z3zxXLh5jb9m4Gjy0S7v/D8fLJmI1mduAx2z2q2w04pMXdZbcZ6wxXTqneVW8PQQPZMXaACseV6s8htIT998XAn+jk2L5i/i1b4xHFwomZSB5Td2YTPnjvo04iboe/mNyzqVwjM0BZ9/6yuDHb9Dg1lNxufmVjkeVvX+Bzlb2/oMv27jxTMxp3ZrLRm95/4Ni6ixcukXOL3PrzEfY6iV/YaNBlVNU84Qc+ox5DEea4JYu36y7xsJyceyNXNWi5OIqWXaMNlrxOJsj7S/3Ei90DHmbI3KIvmlES56W4hUHGJFqXKAKuQbSeCzgRIa4CPW45HAZOyus5eqYbOzk935JLShQkzn5BrtRsie1FkOF8/VfpJg8hU8gT+r9D9ZbFWETsznrBv7MUeENQa097qc5DOR1PTKvdUg3moS+2Cq8bvCN7iIvUDVUbiTsXlDHw8ZgoZyL75eog5I19BfhC4K+azy88s9sYpnA8bPu+Y/1t3WIjZXjxtwN1IsCa8z9oSi6Jk0ll4nGwL272zacXBvIgX7ZjMh9Q88ZX2qZ5XsE51zvj2N4vSDfBzw64h37NxtIq/ujzgCFmvJiOuE+48UnaDqGPYffte/I5nM/1fHkKv8j3R74jhzXMXvebOZQPKVXeR9ysWM6+og4Tdm/Xim5Z/6xLZzPP5jv9WRNVvKSxFgRL/cOZOIs657So9/oR9WIVl7iyhd1CGcUeRrJA8uLhbi+4QuFhi3J04RYiehJydnK90pHPF3pp7crXPNPaiB4bza9gg2QMT2dFZePe62r1pg5IK5B5SlqwKvGn/TDsCafvVt6IvT3JY60vWno4w+Mbq87qLabAzThWmwrnUHxxcr5L9bLrKT88MHfLTQxb73mdh3LriLH/9rtGTeOezrKcbnSS3fQ7qM+cT99Bidh0Tk2iRu9FMv9waAUx2rq55/NVxyzbRYSMTVjlgzM5ykzJkT+40IeWxiP9sLCbVVfWalPnQhTBK7Al12Kvfph/FDWTXW5x/alG/GSqruiL5/CpxGzrJG78RoV82/zpv0JXoicqrfSNYJS98FG5UN7NRnNdF7LFLkR7E4/++f3+7Uw4Rh1DWrAe5uuwhfrBLb2/ve2OXiJCfXgHM2A5url7Ko2N2w0G/oCIuv6RSaeyqsHL1VpVJbfjVnNvbHXtafSTJTNeIWTn84FYO3n0L1s2rT9qLCJHNds93t5XKmaG8WH1nON/6WumPtWcETqkKCxLnnCeg5eb+EffHmwNAf2NQeeL/uKNVFFHlrlsJGPLu6kcWkt8qnfh9HfbGTpsL5oJU1S2KCEOOeOOVfheXo/2HM13bD7YkR6NJjfi6FlnDW1J77U1Ldj2Ob7KOBfZ+aU91HeGT7WOQOH/zdjO0Htij4n80UhHb4AenCzgdGfrNmKNRj6BW36fCPZlCmjMUmieUR23lyuHzYkqZR1jn9566XMUT0YeYU+9Zvsn/uMeoYlX+pLWxzxzf078h1t9XL52Ivg7e3Hq/QgCDnssWN/zysJG5CqF3KH11L8Zby4Dy8KKNAva7Gh33x8NgO+Voy7PgvxuKAeDXln1ixuHV2LllWf9qFrxnTNFXwJ6Ef9Hf9PyiG57kU0jbZVkxz4Ph/9XA6NuO5TPkCp/TyTnG4MH0DjVfNG3qR1P1b4PjH7RSyHoufFdxOYf/WqOajGI/Wc91QDzxi/W+oJpZ41fBF5cO3jbHgZ51gbgzw04iHoptDnZO8F5vLCF7gHtSp8OblwRPkyS9Fv4EVIg+aM+pQJ44NXvuxjoF/eKDJ2I36rRzxc/aLusB6StSO6ZmCUj3g/H72wge/NpumNUVAjkNQjsRoMPS5i3oovIxxYYtds1B/pFINNlcB72aabl4BfxgZI54+IJ7vHPBxi+yto6MT9E/Xh6BXLYUOpqm6ypTD7BV8CqhoH57yB8POrMV5DUMcuL/4LG9Smmllvo5c0Yi2Hmv/6GtxHN6NiTa9uSAXcS+Ig6K3wHF03kG6cFfBvdaMpvrxEGmQFz7mJ6g+yxnHVCCs+56H8BjLLmiDd0Erq0L65TsBP/u4aqrEZG+Vg3dTLhsx9E+tF+RI8lnk3bLSA16z6HyDuScXGP772SHO4MufyyBev76Z8wfZNfiubmHe34Ysmkg3cHsBH/lt6ZYAPwn4k0nvkWXyNYO5D7kIwV03d1E2NtRXqetVY7EYdei1YU40vpxuAVdSLi4NaOtPT/A3hwdvE3tmM+9tzFe/dyKkXU+jzdZ8TOwP7002RgB+xrgk6LS/Yz12jp/LuH6oRomqMprl0wMH5EnuuDfB3301y+3UTL11fCz2Ol3O1NpEuYvzZlr47bBw8GS4DPqDwjCXPigabjXCPZL4gKfGS8QQPjw2BNRbW0LXn0q+E/nHfSDQ1zq5JeDpdN1eiXvKlNkHyg+iBo2sOUcvDpklF9BAy73/YXKmRbKxklO6cSd4tfBo5173/ePwwCugUMH34mOaKn5MC2p8ZH8XCXfHxcVKcPnwaD5+fnw8TZ/Jwn/v8eMzfS2Ol9cb9+L+rj/0vb7rLaq/UWaFEl6q1EpX2IHzgu0xmHaNsNY16ua9brkip5kVoIlRNWPqOLrFiOxdFrUu0MsgLdIAk9LdtkdjyKPw9/s6yil+SXswT9lCOpeJG+aCHcvK9U1JSxVLS2Za9YdFKodxmjzG8W6Kvy1ijUlgf5m0NcyfmPTQnbGWELYUSdUkJ7Tb1PFO/LsKP6S67XHq2Vu9cyv4d4c4vXkelj0+/K42O3oGA6+qS23Wz4s5d6bMvZaT8nCiBRnjPPpZriF/6uKtSZx6LXtUoZ7NYLpo+Hikv9sCjPEyZRg/a8Rz4PgmUtMZdWwmhWRLM97SDdoV+29YlRs3+gvpQzyOtclyoj+l9Zt+yMIS/pr/qd9hKWBaWy8VhU10CTRUcrS16mCP11cccxkqk102UQ2OOWIYHd0epgGRZQQLqRon1gKVdMOmni9qyuUS5dmoNsYVP/+y3b/o4B+NvLgHdV9tFQkyOJWVX8RYAaLsBM+qRFoeekvF7rWkSxxuWMfN9iFm/qWdcbm9TQtPrlAhhjSkhAITADTVnB1eoo4NdcE+UTwtdtwH5kL6Q6veMkBTPAviU14q3QEjNCyC7Ot9l/cW+vSoNG4yh67Ss3H/G5XF4qd6mutbkfa4wK3TJZygDO+2pigmxNVkWUdlsWr0cdAZlha4kS76N2P0JL4Pie56znE0ge96vacX0lrE7gZ6wbWSEkPFxvg/DebwuCdTl2e+DoL1EUL4PSn9ef9cLWwqUwn2wZqmLhfYX6LMvenC5vfEeKKaj4erW0Wfy+GetBIKWF71/KD9Ryd9DPd8+upg7m2EU5rJ+2QZtCMLv2M9etzcJZGU2YdkVKdG6nE3aiYQlcK6UuitdClhn6Hux6wbzErQ3+MLa596eB4W2d6R7sIZt27O8RqChxLmzTbAuTd2uojkM1yKuV7fNy8sR4auBNx3sWp5fSveHjL8/tcPWSCuf0GcA3e+SVOzlbR161ZtxOnl4dB4f4BkU89N7x/jIu/fGfeH+sXQ/cQv3jvv4+Zkr5u/v3M/cZ/6h8FhyP/NO4WN69/gwmTw4f/3rX/8PtDofNcCTAAA='))
 $gzip=New-Object IO.Compression.GZipStream($stream,[IO.Compression.CompressionMode]::Decompress)
 $reader=New-Object IO.StreamReader($gzip)
 try{$payload=$reader.ReadToEnd() | ConvertFrom-Json}finally{$reader.Dispose();$gzip.Dispose();$stream.Dispose()}
 foreach($name in @('agent.py','worker.py','node_metrics.py')){
  $entry=$payload.$name;$bytes=[Convert]::FromBase64String($entry.data);$sha=[Security.Cryptography.SHA256]::Create()
  try{$hash=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  if($hash -ne $entry.sha256){throw "Contenido danado: $name"}
  $target=Join-Path $InstallDir $name
  if(Test-Path -LiteralPath $target){Copy-Item -LiteralPath $target -Destination ($target+'.before-installer') -Force}
  [IO.File]::WriteAllBytes($target,$bytes)
 }
 if(!(Test-Path -LiteralPath $cfgPath)){
  $cfg=[ordered]@{server_url=$ServerUrl;connection_state='unpaired';accept_remote_jobs=$false;max_parallel_jobs=1;ffmpeg_threads=4;minimum_free_gib=5;maximum_source_mib=500;maximum_duration_seconds=10800;process_timeout_seconds=1800;segment_seconds=4;process_priority='below_normal'}
  Save-Text $cfgPath ($cfg | ConvertTo-Json)
 }
 if(!$ConfigureOnly){Save-Text (Join-Path $InstallDir 'tools.json') (@{python=$python;ffmpeg=$ff.ffmpeg;ffprobe=$ff.ffprobe;package='Gyan.FFmpeg';installation='winget --scope user'} | ConvertTo-Json)}
 foreach($dir in @('work','reports','logs','incoming')){New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir $dir) | Out-Null}
 $saved=Join-Path $InstallDir 'Instalar-worker.ps1'
 if($PSCommandPath -ne $saved){Copy-Item -LiteralPath $PSCommandPath -Destination $saved -Force}
 $runner=@'
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach($name in @('arranque-out.log','arranque-error.log')){
 $log=Join-Path $PSScriptRoot ('logs\'+$name)
 if(Test-Path -LiteralPath $log){Move-Item -LiteralPath $log -Destination ($log+'.previous') -Force}
}
try{
 $python=Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
 $agent=Join-Path $PSScriptRoot 'agent.py'
 $p=Start-Process -FilePath $python -ArgumentList @('-u',('"'+$agent+'"'),'run') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -Wait -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'logs\arranque-out.log') -RedirectStandardError (Join-Path $PSScriptRoot 'logs\arranque-error.log')
 exit $p.ExitCode
}catch{$_ | Out-File -LiteralPath (Join-Path $PSScriptRoot 'logs\arranque-error.log') -Append;exit 1}
'@
 Save-Text (Join-Path $InstallDir 'Ejecutar-worker.ps1') $runner
 Save-Text (Join-Path $InstallDir 'Iniciar-worker.cmd') "@echo off`r`ncd /d `"%~dp0`"`r`n`".venv\Scripts\python.exe`" `"agent.py`" run`r`nif errorlevel 1 pause`r`n"
 Save-Text (Join-Path $InstallDir 'Pausar-worker.cmd') "@echo off`r`ncd /d `"%~dp0`"`r`n`".venv\Scripts\python.exe`" `"agent.py`" pause`r`npause`r`n"
 $pairWrapper='& (Join-Path $PSScriptRoot ''Instalar-worker.ps1'') -ConfigureOnly -InstallDir $PSScriptRoot -ServerUrl '+"'"+$ServerUrl.Replace("'","''")+"' -TaskName '"+$TaskName.Replace("'","''")+"'"
 Save-Text (Join-Path $InstallDir 'Vincular-worker.ps1') $pairWrapper
 Save-Text (Join-Path $InstallDir 'Vincular-worker.cmd') "@echo off`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0Vincular-worker.ps1`"`r`npause`r`n"
 Write-Host '[4/6] Comprobando el conversor...'
 & $venv (Join-Path $InstallDir 'worker.py') doctor
 if($LASTEXITCODE -ne 0){throw 'El diagnostico fallo; no se habilitara la tarea.'}
 $auth=Join-Path $private 'agent-auth.json'
 if(!(Test-Path -LiteralPath $auth) -and !$SkipPairing){
  Write-Host "Abre $ServerUrl con tu cuenta gestora: Mi cuenta > Worker de escritorio. Registra esta PC y genera un codigo nuevo."
  $requestId=Read-Host 'ID de solicitud (Enter para vincular despues)'
  if($requestId){
   if($requestId -notmatch '^[a-fA-F0-9]{32}$'){throw 'El ID debe tener 32 caracteres hexadecimales.'}
   $secret=Read-Host 'Codigo temporal (entrada oculta; NO tu contrasena)' -AsSecureString
   $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
   $codeFile=Join-Path $private ('pair-'+[Guid]::NewGuid().ToString('N')+'.tmp')
   try{
    $code=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    if($code -notmatch '^[a-f0-9]{32}$'){throw 'Codigo invalido; genera uno nuevo desde Sparrow-Fy.'}
    Save-Text $codeFile $code
    & $venv (Join-Path $InstallDir 'agent.py') pair --request $requestId --code-file $codeFile
    if($LASTEXITCODE -ne 0){throw 'Vinculacion fallida. Reintenta con Vincular-worker.cmd.'}
   }finally{
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr);$code=$null;$secret.Dispose()
    if(Test-Path -LiteralPath $codeFile){Remove-Item -LiteralPath $codeFile -Force}
   }
  }
 }
 Write-Host '[5/6] Registrando la tarea al iniciar sesion...'
 $powershell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
 $action=New-ScheduledTaskAction -Execute $powershell -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+(Join-Path $InstallDir 'Ejecutar-worker.ps1')+'"') -WorkingDirectory $InstallDir
 $trigger=New-ScheduledTaskTrigger -AtLogOn -User $sid
 $principal=New-ScheduledTaskPrincipal -UserId $sid -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 2)
 $definition=New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Sparrow-Fy: conversiones en esta PC y transferencia HTTPS. Inicio al entrar en Windows; permisos normales.'
 $paired=Test-Path -LiteralPath $auth
 $definition.Settings.Enabled=$paired
 try{Register-ScheduledTask -TaskName $TaskName -InputObject $definition -Force | Out-Null}catch{throw "Windows impidio registrar la tarea: $($_.Exception.Message). Los archivos estan en $InstallDir. Si la politica local exige elevacion, ejecuta Vincular-worker.cmd como administrador de ESTA MISMA cuenta; no uses otra cuenta."}
 Export-ScheduledTask -TaskName $TaskName | Set-Content -LiteralPath (Join-Path $InstallDir 'sparrowfy-worker.xml') -Encoding Unicode
 if($paired){Start-ScheduledTask -TaskName $TaskName;Write-Host '[6/6] Vinculado e iniciado en segundo plano.' -ForegroundColor Green}
 else{Write-Host '[6/6] Instalado; tarea deshabilitada hasta vincular. Ejecuta Vincular-worker.cmd.' -ForegroundColor Yellow}
 Write-Host "Carpeta: $InstallDir"
 Write-Host "Tarea: $TaskName (taskschd.msc)"
 Write-Host 'Actividad: Mi cuenta > Worker de escritorio, logs\agent.log y logs\arranque-error.log.'
 Write-Host 'Arranca al iniciar sesion y funciona con el navegador cerrado. No funciona con la PC apagada o suspendida.'
 exit 0
}catch{Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red;exit 1}

@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-worker.ps1" %*
set "resultado=%errorlevel%"
echo.
if not "%resultado%"=="0" echo La instalacion no termino. Revisa el mensaje anterior.
pause
exit /b %resultado%

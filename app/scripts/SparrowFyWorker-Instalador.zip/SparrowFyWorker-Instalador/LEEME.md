# Instalador del worker Sparrow-Fy para Windows

1. Extrae el ZIP completo en una carpeta.
2. Ejecuta **Instalar-worker.cmd** con tu usuario habitual de Windows.
3. El instalador comprueba winget y trata de registrar App Installer si falta. Si no puede repararlo, indica que instales o actualices App Installer desde https://aka.ms/getwinget y vuelvas a ejecutarlo.
4. Instala Python y FFmpeg/FFprobe para tu usuario cuando faltan, crea un entorno Python y escribe los módulos y lanzadores del worker. No requiere paquetes pip ni claves de IA.
5. En Sparrow-Fy, entra con una cuenta gestora en **Mi cuenta → Worker de escritorio**, registra la PC y genera un código temporal. Introduce el identificador y el código cuando el instalador los solicite. No introduzcas la contraseña de tu cuenta.
6. Registra `sparrowfy-worker` en el Programador de tareas (`taskschd.msc`) y la inicia si se vinculó correctamente. Si pospones la vinculación, la tarea queda deshabilitada: usa `Vincular-worker.cmd` en la carpeta instalada para terminar.

## Identidad, carpeta y arranque

Se verifica la identidad mediante `whoami` y el SID de Windows. La carpeta predeterminada es `%LOCALAPPDATA%\SparrowFyWorker`; no hay rutas fijas ni SID de Armando dentro del instalador. Cada PC recibe su propia credencial. El ZIP no contiene credenciales ni configuración privada del equipo original.

La tarea se ejecuta **al iniciar sesión en Windows**, con la cuenta que instaló el worker y permisos normales (`Interactive`, `Limited`). Arranca oculta, sin límite de tiempo y sin instancias simultáneas. Permite batería y no se detiene al desconectar el cargador. Reintenta tres veces, cada dos minutos, si el proceso termina con error. El propio agente reintenta interrupciones de red.

Funciona con el navegador cerrado o la sesión bloqueada. No funciona con la PC apagada, suspendida o después de cerrar la sesión de Windows. No usa `S4U` ni guarda tu contraseña de Windows. Si una política local exige UAC para registrar tareas, puede requerirse elevación una sola vez, **de la misma cuenta**; el worker conserva permisos normales.

## Archivos instalados

- `Iniciar-worker.cmd`: inicio manual con consola visible. Si ya hay una instancia, se rechaza la segunda.
- `Pausar-worker.cmd`: deja de aceptar tareas y termina la conversión actual antes de salir.
- `Vincular-worker.cmd`: completa la vinculación pospuesta.
- `Ejecutar-worker.ps1`: arranque oculto utilizado por la tarea automática.
- `logs\agent.log`: registro rotatorio de actividad y conversiones.
- `logs\arranque-error.log` y `logs\arranque-out.log`: salida del último arranque; conserva una copia del anterior.
- `sparrowfy-worker.xml`: configuración exportada de la tarea instalada.

Para ver si está conectado, consulta **Mi cuenta → Worker de escritorio** en Sparrow-Fy. La tarea en estado «En ejecución» indica que el proceso está iniciado; no garantiza por sí sola que el servidor esté accesible.

## Opciones

Desde PowerShell, sin cambiar permanentemente la política de ejecución:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Instalar-worker.ps1
```

Otra carpeta, servidor o nombre de tarea:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Instalar-worker.ps1 -InstallDir "D:\SparrowFyWorker" -ServerUrl "https://sparrowfy.ddns.info/" -TaskName "SparrowFy-Worker"
```

Preparar sin pedir el código todavía: añade `-SkipPairing`.

Si ya existe una tarea con el mismo nombre que apunta a otra carpeta o tiene otra configuración, el instalador se detiene sin reemplazarla. No copies `private` a otras computadoras. Antes de reinstalar en una carpeta activa, pausa el worker y espera a que termine.

## Validación realizada

Se verificaron la sintaxis de PowerShell, la integridad SHA-256 de los tres módulos incluidos y una instalación aislada con tareas simuladas y sin vinculación. La instalación de paquetes no se repitió en la PC de desarrollo, porque ya cuenta con Python y FFmpeg.
